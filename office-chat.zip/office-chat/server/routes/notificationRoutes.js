const router = require('express').Router();
const { protect } = require('../middleware/auth');
const { listNotifications, markRead, markAllRead } = require('../controllers/notificationController');

router.use(protect);

router.get('/', listNotifications);
router.patch('/:id/read', markRead);
router.patch('/read-all', markAllRead);

module.exports = router;

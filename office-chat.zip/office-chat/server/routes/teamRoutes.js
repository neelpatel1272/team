const router = require('express').Router();
const { protect } = require('../middleware/auth');
const { listTeams, createTeam, getTeam, addTeamMembers } = require('../controllers/teamController');

router.use(protect);

router.get('/', listTeams);
router.post('/', createTeam);
router.get('/:id', getTeam);
router.post('/:id/members', addTeamMembers);

module.exports = router;

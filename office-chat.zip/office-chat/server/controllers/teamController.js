const Team = require('../models/Team');
const TeamMember = require('../models/TeamMember');
const Conversation = require('../models/Conversation');
const ConversationMember = require('../models/ConversationMember');
const { ok, fail } = require('../utils/apiResponse');
const { CONVERSATION_TYPE, MEMBER_ROLE } = require('../config/constants');

async function listTeams(req, res, next) {
  try {
    const memberships = await TeamMember.find({ user: req.user._id }).select('team');
    const teamIds = memberships.map((m) => m.team);
    const teams = await Team.find({ _id: { $in: teamIds } }).populate('conversation');

    const withCounts = await Promise.all(
      teams.map(async (team) => ({
        ...team.toObject(),
        memberCount: await TeamMember.countDocuments({ team: team._id }),
      }))
    );

    return ok(res, { teams: withCounts });
  } catch (err) {
    next(err);
  }
}

async function createTeam(req, res, next) {
  try {
    const { name, description, icon, color, memberIds = [] } = req.body;
    if (!name) return fail(res, 'Team name is required.', 400);

    const conversation = await Conversation.create({
      type: CONVERSATION_TYPE.TEAM,
      name,
      description,
      createdBy: req.user._id,
    });

    const team = await Team.create({ name, description, icon, color, conversation: conversation._id, createdBy: req.user._id });
    conversation.team = team._id;
    await conversation.save();

    const uniqueMemberIds = Array.from(new Set([...memberIds, String(req.user._id)]));
    await Promise.all([
      TeamMember.create(
        uniqueMemberIds.map((uid) => ({ team: team._id, user: uid, role: uid === String(req.user._id) ? MEMBER_ROLE.OWNER : MEMBER_ROLE.MEMBER }))
      ),
      ConversationMember.create(
        uniqueMemberIds.map((uid) => ({ conversation: conversation._id, user: uid, role: uid === String(req.user._id) ? MEMBER_ROLE.OWNER : MEMBER_ROLE.MEMBER }))
      ),
    ]);

    return ok(res, { team, conversation }, 'Team created.', 201);
  } catch (err) {
    next(err);
  }
}

async function getTeam(req, res, next) {
  try {
    const team = await Team.findById(req.params.id).populate('conversation');
    if (!team) return fail(res, 'Team not found.', 404);

    const members = await TeamMember.find({ team: team._id }).populate('user', '-password');
    return ok(res, { team, members });
  } catch (err) {
    next(err);
  }
}

async function addTeamMembers(req, res, next) {
  try {
    const { memberIds = [] } = req.body;
    const team = await Team.findById(req.params.id);
    if (!team) return fail(res, 'Team not found.', 404);

    const existing = await TeamMember.find({ team: team._id }).select('user');
    const existingIds = new Set(existing.map((m) => String(m.user)));
    const newIds = memberIds.filter((id) => !existingIds.has(String(id)));

    if (newIds.length) {
      await TeamMember.create(newIds.map((uid) => ({ team: team._id, user: uid, role: MEMBER_ROLE.MEMBER })));
      await ConversationMember.create(newIds.map((uid) => ({ conversation: team.conversation, user: uid, role: MEMBER_ROLE.MEMBER })));
    }

    return ok(res, null, 'Members added to team.');
  } catch (err) {
    next(err);
  }
}

module.exports = { listTeams, createTeam, getTeam, addTeamMembers };

const Call = require('../models/Call');
const { ok } = require('../utils/apiResponse');

async function getCallHistory(req, res, next) {
  try {
    const calls = await Call.find({
      $or: [{ caller: req.user._id }, { callee: req.user._id }],
    })
      .populate('caller', 'firstName lastName profileImage')
      .populate('callee', 'firstName lastName profileImage')
      .sort({ createdAt: -1 })
      .limit(100);

    const withDirection = calls.map((call) => ({
      ...call.toObject(),
      direction: String(call.caller._id) === String(req.user._id) ? 'outgoing' : 'incoming',
    }));

    return ok(res, { calls: withDirection });
  } catch (err) {
    next(err);
  }
}

// Returns STUN/TURN server config for the frontend's RTCPeerConnection.
// Credentials live only in server env vars — never hardcoded in client source.
async function getIceServers(req, res) {
  const iceServers = [];

  (process.env.STUN_SERVERS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
    .forEach((url) => iceServers.push({ urls: url }));

  if (process.env.TURN_URL) {
    iceServers.push({
      urls: process.env.TURN_URL,
      username: process.env.TURN_USERNAME,
      credential: process.env.TURN_CREDENTIAL,
    });
  }

  return ok(res, { iceServers });
}

module.exports = { getCallHistory, getIceServers };

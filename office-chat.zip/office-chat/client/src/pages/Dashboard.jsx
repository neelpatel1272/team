import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageCircle, Users, Calendar, Folder, PhoneMissed, Video } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSocketContext } from '../contexts/SocketContext';
import { CONVERSATION_API, USER_API, CALL_API } from '../services/api';
import Topbar from '../components/Topbar';
import UserAvatar from '../components/UserAvatar';
import { Skeleton } from '../components/LoadingSkeleton';
import { formatRelativeTime } from '../utils/format';

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

export default function Dashboard() {
  const { user } = useAuth();
  const { isOnline } = useSocketContext();
  const navigate = useNavigate();

  const [conversations, setConversations] = useState([]);
  const [teammates, setTeammates] = useState([]);
  const [calls, setCalls] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([CONVERSATION_API.list(), USER_API.list(), CALL_API.history()])
      .then(([convRes, userRes, callRes]) => {
        setConversations(convRes.data.data.conversations);
        setTeammates(userRes.data.data.users);
        setCalls(callRes.data.data.calls);
      })
      .finally(() => setLoading(false));
  }, []);

  const unreadTotal = conversations.reduce((sum, c) => sum + (c.unreadCount || 0), 0);
  const onlineCount = teammates.filter((t) => isOnline(t._id)).length;
  const missedCalls = calls.filter((c) => c.status === 'missed' && c.direction === 'incoming');
  const recentConversations = conversations.slice(0, 5);

  return (
    <div className="main-pane" style={{ width: '100%' }}>
      <Topbar title="Dashboard" />
      <div style={{ padding: 28, overflowY: 'auto', flex: 1 }}>
        <h1 style={{ margin: '0 0 4px', fontSize: 24 }}>{greeting()}, {user.firstName} 👋</h1>
        <p className="muted" style={{ marginTop: 0, marginBottom: 26 }}>Here's what's happening across your workspace today.</p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16, marginBottom: 28 }}>
          <StatCard icon={<MessageCircle size={18} />} value={unreadTotal} label="Unread Messages" onClick={() => navigate('/chat')} />
          <StatCard icon={<Users size={18} />} value={onlineCount} label="Online Team Members" onClick={() => navigate('/chat')} />
          <StatCard icon={<Calendar size={18} />} value={0} label="Upcoming Meetings" />
          <StatCard icon={<Folder size={18} />} value={conversations.length} label="Active Conversations" onClick={() => navigate('/files')} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 20 }}>
          <div className="card" style={{ padding: 20 }}>
            <div className="flex items-center justify-between" style={{ marginBottom: 14 }}>
              <h3 style={{ margin: 0, fontSize: 16 }}>Recent conversations</h3>
              <button className="btn-ghost text-sm" onClick={() => navigate('/chat')}>View all</button>
            </div>
            {loading && <Skeleton height={60} style={{ marginBottom: 10 }} />}
            {!loading && recentConversations.length === 0 && <div className="muted text-sm">No conversations yet.</div>}
            {!loading && recentConversations.map((c) => {
              const label = c.type === 'direct' ? (c.otherUser ? `${c.otherUser.firstName} ${c.otherUser.lastName}` : 'Direct message') : c.name;
              return (
                <div key={c._id} className="convo-item" style={{ borderRadius: 10, padding: '10px 6px' }} onClick={() => navigate(`/chat/${c._id}`)}>
                  {c.type === 'direct' ? <UserAvatar user={c.otherUser} size={40} showStatus /> : (
                    <div className="avatar" style={{ width: 40, height: 40 }}><div className="avatar__fallback">{(label || 'G').charAt(0)}</div></div>
                  )}
                  <div className="convo-item__body">
                    <div className="convo-item__name">{label}</div>
                    <div className="convo-item__preview">{c.lastMessage?.content || 'No messages yet'}</div>
                  </div>
                  {c.unreadCount > 0 && <span className="unread-badge">{c.unreadCount}</span>}
                </div>
              );
            })}
          </div>

          <div className="flex-col gap-3">
            <div className="card" style={{ padding: 20 }}>
              <h3 style={{ margin: '0 0 14px', fontSize: 16 }}>Online teammates</h3>
              {loading && <Skeleton height={40} />}
              {!loading && teammates.filter((t) => isOnline(t._id)).slice(0, 6).map((t) => (
                <div key={t._id} className="flex items-center gap-2" style={{ marginBottom: 10 }}>
                  <UserAvatar user={t} size={32} showStatus />
                  <div className="text-sm">{t.firstName} {t.lastName}</div>
                </div>
              ))}
              {!loading && teammates.filter((t) => isOnline(t._id)).length === 0 && (
                <div className="muted text-sm">No one else is online right now.</div>
              )}
            </div>

            <div className="card" style={{ padding: 20 }}>
              <div className="flex items-center justify-between" style={{ marginBottom: 12 }}>
                <h3 style={{ margin: 0, fontSize: 16 }}>Missed calls</h3>
                <button className="btn-ghost text-sm" onClick={() => navigate('/calls')}>View all</button>
              </div>
              {missedCalls.length === 0 && <div className="muted text-sm">No missed calls. 🎉</div>}
              {missedCalls.slice(0, 4).map((c) => (
                <div key={c._id} className="flex items-center gap-2" style={{ marginBottom: 10 }}>
                  {c.type === 'video' ? <Video size={15} className="muted" /> : <PhoneMissed size={15} color="var(--color-danger)" />}
                  <div className="text-sm">{c.caller.firstName} {c.caller.lastName}</div>
                  <div className="text-sm muted" style={{ marginLeft: 'auto' }}>{formatRelativeTime(c.createdAt)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, value, label, onClick }) {
  return (
    <div className="stat-card" onClick={onClick} style={{ cursor: onClick ? 'pointer' : 'default' }}>
      <div className="flex items-center gap-2 muted">{icon}</div>
      <div className="stat-card__value">{value}</div>
      <div className="stat-card__label">{label}</div>
    </div>
  );
}

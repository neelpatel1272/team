import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Plus, X } from 'lucide-react';
import Topbar from '../components/Topbar';
import EmptyState from '../components/EmptyState';
import { Skeleton } from '../components/LoadingSkeleton';
import { TEAM_API, USER_API } from '../services/api';
import UserAvatar from '../components/UserAvatar';
import { useToast } from '../contexts/ToastContext';

export default function Teams() {
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const navigate = useNavigate();

  const load = () => TEAM_API.list().then(({ data }) => setTeams(data.data.teams)).finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  return (
    <div className="main-pane" style={{ width: '100%' }}>
      <Topbar title="Teams" />
      <div style={{ padding: 28, overflowY: 'auto', flex: 1 }}>
        <div className="flex items-center justify-between" style={{ marginBottom: 20 }}>
          <p className="muted" style={{ margin: 0 }}>Team spaces for departments and cross-functional groups.</p>
          <button className="btn btn-primary" onClick={() => setModalOpen(true)}><Plus size={15} /> New team</button>
        </div>

        {loading && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 16 }}>
            {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} height={110} />)}
          </div>
        )}

        {!loading && teams.length === 0 && (
          <EmptyState icon={<Users size={26} className="muted" />} title="No teams yet" description="Create a team space for your department or project." />
        )}

        {!loading && teams.length > 0 && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 16 }}>
            {teams.map((team) => (
              <div
                key={team._id}
                className="card"
                style={{ padding: 20, cursor: 'pointer' }}
                onClick={() => navigate(`/chat/${team.conversation?._id || team.conversation}`)}
              >
                <div
                  style={{
                    width: 44, height: 44, borderRadius: 12, background: team.color || 'var(--color-primary)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, marginBottom: 12, color: '#fff',
                  }}
                >
                  {team.icon || team.name.charAt(0)}
                </div>
                <div className="font-bold" style={{ marginBottom: 4 }}>{team.name}</div>
                <div className="text-sm muted" style={{ marginBottom: 10 }}>{team.description || 'Team workspace'}</div>
                <div className="text-sm muted">{team.memberCount} member{team.memberCount === 1 ? '' : 's'}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      <NewTeamModal open={modalOpen} onClose={() => setModalOpen(false)} onCreated={load} />
    </div>
  );
}

function NewTeamModal({ open, onClose, onCreated }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [users, setUsers] = useState([]);
  const [selected, setSelected] = useState([]);
  const [loading, setLoading] = useState(false);
  const { showToast } = useToast();

  useEffect(() => {
    if (open) USER_API.list().then(({ data }) => setUsers(data.data.users));
    else { setName(''); setDescription(''); setSelected([]); }
  }, [open]);

  if (!open) return null;

  const toggle = (id) => setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));

  const create = async () => {
    if (!name.trim()) return;
    setLoading(true);
    try {
      await TEAM_API.create({ name, description, memberIds: selected });
      onCreated();
      onClose();
    } catch {
      showToast('Unable to create team.', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal__header">
          <span className="modal__title">New team space</span>
          <button className="btn-icon" onClick={onClose}><X size={16} /></button>
        </div>
        <div className="modal__body">
          <div className="field">
            <label>Team name</label>
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Product Design" />
          </div>
          <div className="field">
            <label>Description</label>
            <input className="input" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What's this team about?" />
          </div>
          <div className="field">
            <label>Add members</label>
            <div style={{ maxHeight: 200, overflowY: 'auto', border: '1px solid var(--color-border)', borderRadius: 10 }}>
              {users.map((u) => (
                <div key={u._id} className="convo-item" style={{ borderRadius: 0 }} onClick={() => toggle(u._id)}>
                  <input type="checkbox" checked={selected.includes(u._id)} readOnly style={{ marginRight: 4 }} />
                  <UserAvatar user={u} size={30} />
                  <div className="convo-item__body"><div className="convo-item__name">{u.firstName} {u.lastName}</div></div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="modal__footer">
          <button className="btn btn-outline" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={!name.trim() || loading} onClick={create}>Create team</button>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Phone, Video, MoreVertical, Pin, Folder, ArrowLeft } from 'lucide-react';
import UserAvatar from './UserAvatar';
import { useCall } from '../contexts/CallContext';
import { useSocketContext } from '../contexts/SocketContext';

const STATUS_LABEL = { online: 'Online', away: 'Away', busy: 'Busy', dnd: 'Do Not Disturb', offline: 'Offline' };

export default function ChatHeader({ conversation, onOpenPinned, onOpenFiles, onBack }) {
  const { placeCall } = useCall();
  const { isOnline } = useSocketContext();
  const [menuOpen, setMenuOpen] = useState(false);

  if (!conversation) return null;

  const isDirect = conversation.type === 'direct';
  const peer = conversation.otherUser;
  const online = isDirect && peer ? isOnline(peer._id) : false;
  const name = isDirect ? (peer ? `${peer.firstName} ${peer.lastName}` : 'Direct message') : conversation.name;

  const startCall = (type) => {
    if (!isDirect || !peer) return;
    placeCall({ calleeId: peer._id, calleeName: `${peer.firstName} ${peer.lastName}`, calleeImage: peer.profileImage, type, conversationId: conversation._id });
  };

  return (
    <header className="chat-header">
      <div className="chat-header__info">
        <button className="btn-icon" style={{ display: 'none' }} onClick={onBack}><ArrowLeft size={18} /></button>
        {isDirect ? <UserAvatar user={peer} size={42} showStatus /> : (
          <div className="avatar" style={{ width: 42, height: 42 }}>
            <div className="avatar__fallback">{conversation.type === 'team' ? '🏢' : (name || 'G').charAt(0)}</div>
          </div>
        )}
        <div>
          <div className="chat-header__name">{name}</div>
          <div className="chat-header__status">
            {isDirect ? (online ? STATUS_LABEL.online : STATUS_LABEL.offline) : `${conversation.memberCount || ''} members`}
            {isDirect && peer?.jobTitle && <span> · {peer.jobTitle}</span>}
          </div>
        </div>
      </div>

      <div className="chat-header__actions">
        {isDirect && (
          <>
            <button className="btn-icon" onClick={() => startCall('audio')} title="Audio call"><Phone size={17} /></button>
            <button className="btn-icon" onClick={() => startCall('video')} title="Video call"><Video size={17} /></button>
          </>
        )}
        <button className="btn-icon" onClick={onOpenPinned} title="Pinned messages"><Pin size={17} /></button>
        <button className="btn-icon" onClick={onOpenFiles} title="Shared files"><Folder size={17} /></button>
        <div style={{ position: 'relative' }}>
          <button className="btn-icon" onClick={() => setMenuOpen((o) => !o)}><MoreVertical size={17} /></button>
          {menuOpen && (
            <>
              <div style={{ position: 'fixed', inset: 0, zIndex: 5 }} onClick={() => setMenuOpen(false)} />
              <div className="card" style={{ position: 'absolute', right: 0, top: 44, width: 190, padding: 6, zIndex: 6 }}>
                <button className="btn-ghost text-sm" style={{ width: '100%', textAlign: 'left', padding: 9 }} onClick={() => { onOpenPinned(); setMenuOpen(false); }}>Pinned messages</button>
                <button className="btn-ghost text-sm" style={{ width: '100%', textAlign: 'left', padding: 9 }} onClick={() => { onOpenFiles(); setMenuOpen(false); }}>Shared files</button>
                <button className="btn-ghost text-sm" style={{ width: '100%', textAlign: 'left', padding: 9 }}>Mute notifications</button>
                {!isDirect && <button className="btn-ghost text-sm" style={{ width: '100%', textAlign: 'left', padding: 9, color: 'var(--color-danger)' }}>Leave conversation</button>}
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

import { useNavigate } from 'react-router-dom';
import { Bell, MessageCircle, AtSign, Phone, FileText, Users, Megaphone, CheckCheck } from 'lucide-react';
import { useSocketContext } from '../contexts/SocketContext';
import { formatRelativeTime } from '../utils/format';

const ICONS = {
  message: MessageCircle,
  mention: AtSign,
  call: Phone,
  file: FileText,
  group_invite: Users,
  announcement: Megaphone,
};

export default function NotificationPanel({ open, onClose }) {
  const { notifications, unreadNotifCount, markAllNotificationsRead } = useSocketContext();
  const navigate = useNavigate();

  if (!open) return null;

  const go = (n) => {
    onClose();
    if (n.conversation) navigate(`/chat/${n.conversation._id || n.conversation}`);
  };

  return (
    <div className="overlay" onClick={onClose} style={{ background: 'transparent', alignItems: 'flex-start', justifyContent: 'flex-end' }}>
      <div
        className="modal"
        style={{ marginTop: 60, marginRight: 20, maxWidth: 360, width: 360 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="modal__header">
          <div className="flex items-center gap-2">
            <Bell size={18} />
            <span className="modal__title">Notifications</span>
          </div>
          {unreadNotifCount > 0 && (
            <button className="btn-ghost text-sm flex items-center gap-1" onClick={markAllNotificationsRead}>
              <CheckCheck size={14} /> Mark all read
            </button>
          )}
        </div>
        <div style={{ maxHeight: '60vh', overflowY: 'auto' }}>
          {notifications.length === 0 && (
            <div className="muted text-sm" style={{ padding: 24, textAlign: 'center' }}>You're all caught up.</div>
          )}
          {notifications.map((n) => {
            const Icon = ICONS[n.type] || Bell;
            return (
              <div
                key={n._id}
                onClick={() => go(n)}
                className="flex gap-3"
                style={{
                  padding: '12px 16px',
                  cursor: 'pointer',
                  borderBottom: '1px solid var(--color-border)',
                  background: n.isRead ? 'transparent' : 'rgba(79,70,229,0.06)',
                }}
              >
                <div className="avatar" style={{ width: 34, height: 34 }}>
                  <div className="avatar__fallback"><Icon size={15} /></div>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="text-sm font-bold">{n.title}</div>
                  <div className="text-sm muted" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{n.body}</div>
                  <div className="text-sm muted" style={{ fontSize: 11, marginTop: 2 }}>{formatRelativeTime(n.createdAt)}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

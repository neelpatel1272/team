import { NavLink } from 'react-router-dom';
import { Home, MessageCircle, Phone, Folder, Users, Settings, MessageSquare } from 'lucide-react';

const NAV_ITEMS = [
  { to: '/', icon: Home, label: 'Home', end: true },
  { to: '/chat', icon: MessageCircle, label: 'Chat' },
  { to: '/calls', icon: Phone, label: 'Calls' },
  { to: '/files', icon: Folder, label: 'Files' },
  { to: '/teams', icon: Users, label: 'Teams' },
  { to: '/settings', icon: Settings, label: 'Settings' },
];

export default function Sidebar() {
  return (
    <aside className="rail">
      <div className="rail__logo"><MessageSquare size={20} /></div>
      <nav className="rail__nav">
        {NAV_ITEMS.map(({ to, icon: Icon, label, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) => `rail__item${isActive ? ' active' : ''}`}
            title={label}
            aria-label={label}
          >
            <Icon size={22} />
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}

import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Bell, LogOut, User as UserIcon, Settings as SettingsIcon, ChevronDown } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSocketContext } from '../contexts/SocketContext';
import UserAvatar from './UserAvatar';
import SearchModal from './SearchModal';
import NotificationPanel from './NotificationPanel';

export default function Topbar({ title }) {
  const { user, logout } = useAuth();
  const { unreadNotifCount, connectionState } = useSocketContext();
  const [searchOpen, setSearchOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    function onKey(e) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <header className="chat-header" style={{ borderBottom: '1px solid var(--color-border)' }}>
      <div className="chat-header__info">
        <span style={{ fontWeight: 700, fontSize: 17 }}>{title}</span>
        {connectionState !== 'connected' && (
          <span
            className="text-sm"
            style={{
              color: connectionState === 'reconnecting' ? 'var(--color-warning)' : 'var(--color-danger)',
              fontWeight: 600,
            }}
          >
            {connectionState === 'reconnecting' ? '🟡 Reconnecting...' : '🔴 Offline'}
          </span>
        )}
      </div>

      <div className="chat-header__actions">
        <button className="btn btn-outline flex items-center gap-2" onClick={() => setSearchOpen(true)} style={{ padding: '8px 14px' }}>
          <Search size={15} />
          <span className="text-sm muted">Search</span>
          <kbd className="text-sm muted" style={{ border: '1px solid var(--color-border)', borderRadius: 4, padding: '0 5px' }}>Ctrl K</kbd>
        </button>

        <button className="btn-icon" style={{ position: 'relative' }} onClick={() => setNotifOpen((o) => !o)}>
          <Bell size={18} />
          {unreadNotifCount > 0 && <span className="rail__badge" style={{ top: -2, right: -2 }}>{unreadNotifCount}</span>}
        </button>

        <div style={{ position: 'relative' }}>
          <button className="flex items-center gap-2 btn-ghost" style={{ borderRadius: 999, padding: 4 }} onClick={() => setMenuOpen((o) => !o)}>
            <UserAvatar user={user} size={34} showStatus />
            <ChevronDown size={14} />
          </button>
          {menuOpen && (
            <>
              <div style={{ position: 'fixed', inset: 0, zIndex: 40 }} onClick={() => setMenuOpen(false)} />
              <div
                className="card"
                style={{ position: 'absolute', right: 0, top: 46, width: 200, padding: 6, zIndex: 41 }}
              >
                <button
                  className="btn-ghost flex items-center gap-2 text-sm"
                  style={{ width: '100%', justifyContent: 'flex-start', padding: '9px 10px' }}
                  onClick={() => { setMenuOpen(false); navigate('/profile'); }}
                >
                  <UserIcon size={15} /> Profile
                </button>
                <button
                  className="btn-ghost flex items-center gap-2 text-sm"
                  style={{ width: '100%', justifyContent: 'flex-start', padding: '9px 10px' }}
                  onClick={() => { setMenuOpen(false); navigate('/settings'); }}
                >
                  <SettingsIcon size={15} /> Settings
                </button>
                <button
                  className="btn-ghost flex items-center gap-2 text-sm"
                  style={{ width: '100%', justifyContent: 'flex-start', padding: '9px 10px', color: 'var(--color-danger)' }}
                  onClick={logout}
                >
                  <LogOut size={15} /> Logout
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      <SearchModal open={searchOpen} onClose={() => setSearchOpen(false)} />
      <NotificationPanel open={notifOpen} onClose={() => setNotifOpen(false)} />
    </header>
  );
}

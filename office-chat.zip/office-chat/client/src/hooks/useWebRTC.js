import { useCallback, useRef, useState } from 'react';
import { SOCKET_EVENTS } from '../utils/socketEvents';
import { CALL_API } from '../services/api';

// Encapsulates one WebRTC peer connection for a 1:1 audio/video call.
// Socket.IO is used ONLY to exchange SDP offers/answers and ICE candidates;
// once connected, audio/video/screen-share flows directly between the two
// browsers over the negotiated peer connection.
export function useWebRTC({ socket, currentUserId }) {
  const pcRef = useRef(null);
  const localStreamRef = useRef(null);
  const screenStreamRef = useRef(null);
  const remoteUserIdRef = useRef(null);
  const callIdRef = useRef(null);
  const pendingCandidatesRef = useRef([]);

  const [localStream, setLocalStream] = useState(null);
  const [remoteStream, setRemoteStream] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState('idle'); // idle | connecting | connected | reconnecting | ended | failed
  const [isScreenSharing, setIsScreenSharing] = useState(false);

  const getIceServers = useCallback(async () => {
    try {
      const { data } = await CALL_API.iceServers();
      return data.data.iceServers?.length ? data.data.iceServers : [{ urls: 'stun:stun.l.google.com:19302' }];
    } catch {
      return [{ urls: 'stun:stun.l.google.com:19302' }];
    }
  }, []);

  const createPeerConnection = useCallback(
    async (remoteUserId, callId) => {
      const iceServers = await getIceServers();
      const pc = new RTCPeerConnection({ iceServers });
      remoteUserIdRef.current = remoteUserId;
      callIdRef.current = callId;

      pc.onicecandidate = (event) => {
        if (event.candidate) {
          socket.emit(SOCKET_EVENTS.CALL_ICE_CANDIDATE, {
            targetUserId: remoteUserId,
            candidate: event.candidate,
            callId,
          });
        }
      };

      pc.ontrack = (event) => {
        setRemoteStream(event.streams[0]);
      };

      pc.onconnectionstatechange = () => {
        if (pc.connectionState === 'connected') setConnectionStatus('connected');
        else if (pc.connectionState === 'disconnected') setConnectionStatus('reconnecting');
        else if (['failed', 'closed'].includes(pc.connectionState)) setConnectionStatus('failed');
      };

      pcRef.current = pc;
      return pc;
    },
    [getIceServers, socket]
  );

  const getLocalMedia = useCallback(async ({ audio = true, video = true }) => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio, video });
    localStreamRef.current = stream;
    setLocalStream(stream);
    return stream;
  }, []);

  // Caller side: create offer and send it
  const startCall = useCallback(
    async ({ calleeId, callId, type }) => {
      setConnectionStatus('connecting');
      const stream = await getLocalMedia({ audio: true, video: type === 'video' });
      const pc = await createPeerConnection(calleeId, callId);
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      socket.emit(SOCKET_EVENTS.CALL_OFFER, { targetUserId: calleeId, sdp: offer, callId });
    },
    [createPeerConnection, getLocalMedia, socket]
  );

  // Callee side: accept then wait for/handle the offer
  const prepareToAnswer = useCallback(
    async ({ callerId, callId, type }) => {
      setConnectionStatus('connecting');
      const stream = await getLocalMedia({ audio: true, video: type === 'video' });
      const pc = await createPeerConnection(callerId, callId);
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));
      return pc;
    },
    [createPeerConnection, getLocalMedia]
  );

  const handleOffer = useCallback(
    async ({ fromUserId, sdp, callId }) => {
      let pc = pcRef.current;
      if (!pc) {
        pc = await createPeerConnection(fromUserId, callId);
      }
      await pc.setRemoteDescription(new RTCSessionDescription(sdp));

      // Flush any ICE candidates that arrived before the remote description was set
      for (const candidate of pendingCandidatesRef.current) {
        await pc.addIceCandidate(new RTCIceCandidate(candidate)).catch(() => {});
      }
      pendingCandidatesRef.current = [];

      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      socket.emit(SOCKET_EVENTS.CALL_ANSWER, { targetUserId: fromUserId, sdp: answer, callId });
    },
    [createPeerConnection, socket]
  );

  const handleAnswer = useCallback(async ({ sdp }) => {
    const pc = pcRef.current;
    if (!pc) return;
    await pc.setRemoteDescription(new RTCSessionDescription(sdp));
  }, []);

  const handleRemoteIceCandidate = useCallback(async ({ candidate }) => {
    const pc = pcRef.current;
    if (!pc || !pc.remoteDescription) {
      pendingCandidatesRef.current.push(candidate);
      return;
    }
    try {
      await pc.addIceCandidate(new RTCIceCandidate(candidate));
    } catch (err) {
      console.warn('[webrtc] Failed to add ICE candidate', err);
    }
  }, []);

  const toggleMute = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return false;
    const audioTrack = stream.getAudioTracks()[0];
    if (!audioTrack) return false;
    audioTrack.enabled = !audioTrack.enabled;
    return !audioTrack.enabled; // returns isMuted
  }, []);

  const toggleCamera = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return false;
    const videoTrack = stream.getVideoTracks()[0];
    if (!videoTrack) return false;
    videoTrack.enabled = !videoTrack.enabled;
    return !videoTrack.enabled; // returns isCameraOff
  }, []);

  const startScreenShare = useCallback(async () => {
    const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
    screenStreamRef.current = screenStream;
    const screenTrack = screenStream.getVideoTracks()[0];

    const pc = pcRef.current;
    const sender = pc?.getSenders().find((s) => s.track && s.track.kind === 'video');
    if (sender) await sender.replaceTrack(screenTrack);

    setIsScreenSharing(true);
    if (remoteUserIdRef.current) {
      socket.emit(SOCKET_EVENTS.SCREEN_SHARE_START, { targetUserId: remoteUserIdRef.current, callId: callIdRef.current });
    }

    screenTrack.onended = () => stopScreenShare();
    return screenStream;
  }, [socket]);

  const stopScreenShare = useCallback(async () => {
    const pc = pcRef.current;
    const cameraTrack = localStreamRef.current?.getVideoTracks()[0];
    const sender = pc?.getSenders().find((s) => s.track && s.track.kind === 'video');
    if (sender && cameraTrack) await sender.replaceTrack(cameraTrack);

    screenStreamRef.current?.getTracks().forEach((t) => t.stop());
    screenStreamRef.current = null;
    setIsScreenSharing(false);

    if (remoteUserIdRef.current) {
      socket.emit(SOCKET_EVENTS.SCREEN_SHARE_STOP, { targetUserId: remoteUserIdRef.current, callId: callIdRef.current });
    }
  }, [socket]);

  const endCall = useCallback(() => {
    if (remoteUserIdRef.current && callIdRef.current) {
      socket.emit(SOCKET_EVENTS.CALL_END, { callId: callIdRef.current, otherUserId: remoteUserIdRef.current });
    }
    localStreamRef.current?.getTracks().forEach((t) => t.stop());
    screenStreamRef.current?.getTracks().forEach((t) => t.stop());
    pcRef.current?.close();

    pcRef.current = null;
    localStreamRef.current = null;
    screenStreamRef.current = null;
    remoteUserIdRef.current = null;
    callIdRef.current = null;
    pendingCandidatesRef.current = [];

    setLocalStream(null);
    setRemoteStream(null);
    setIsScreenSharing(false);
    setConnectionStatus('ended');
  }, [socket]);

  return {
    localStream,
    remoteStream,
    connectionStatus,
    isScreenSharing,
    startCall,
    prepareToAnswer,
    handleOffer,
    handleAnswer,
    handleRemoteIceCandidate,
    toggleMute,
    toggleCamera,
    startScreenShare,
    stopScreenShare,
    endCall,
  };
}

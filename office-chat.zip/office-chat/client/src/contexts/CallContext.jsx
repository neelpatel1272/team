import { createContext, useContext, useEffect, useRef, useState, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { useSocketContext } from './SocketContext';
import { useWebRTC } from '../hooks/useWebRTC';
import { SOCKET_EVENTS } from '../utils/socketEvents';

const CallContext = createContext(null);

export function CallProvider({ children }) {
  const { user } = useAuth();
  const { socket } = useSocketContext();
  const webrtc = useWebRTC({ socket, currentUserId: user?._id });

  // incomingCall: { callId, type, conversationId, caller }
  const [incomingCall, setIncomingCall] = useState(null);
  // activeCall: { callId, type, peer: { id, name, profileImage }, direction }
  const [activeCall, setActiveCall] = useState(null);
  const [callError, setCallError] = useState(null);

  const activeCallRef = useRef(null);
  useEffect(() => {
    activeCallRef.current = activeCall;
  }, [activeCall]);

  useEffect(() => {
    if (!socket) return undefined;

    const onRinging = ({ callId, type, conversationId, caller }) => {
      // If already on a call, silently ignore (a "busy" reply could be added server-side later)
      if (activeCallRef.current) return;
      setIncomingCall({ callId, type, conversationId, caller });
    };

    const onOffer = async (payload) => {
      await webrtc.handleOffer(payload);
    };
    const onAnswer = async (payload) => {
      await webrtc.handleAnswer(payload);
    };
    const onIceCandidate = async (payload) => {
      await webrtc.handleRemoteIceCandidate(payload);
    };
    const onAccept = () => {
      setActiveCall((prev) => (prev ? { ...prev, status: 'connecting' } : prev));
    };
    const onReject = () => {
      setCallError('Call declined.');
      webrtc.endCall();
      setActiveCall(null);
    };
    const onEnd = () => {
      webrtc.endCall();
      setActiveCall(null);
      setIncomingCall(null);
    };
    const onBusy = () => {
      setCallError('That teammate is currently offline.');
      setActiveCall(null);
    };

    socket.on(SOCKET_EVENTS.CALL_RINGING, onRinging);
    socket.on(SOCKET_EVENTS.CALL_OFFER, onOffer);
    socket.on(SOCKET_EVENTS.CALL_ANSWER, onAnswer);
    socket.on(SOCKET_EVENTS.CALL_ICE_CANDIDATE, onIceCandidate);
    socket.on(SOCKET_EVENTS.CALL_ACCEPT, onAccept);
    socket.on(SOCKET_EVENTS.CALL_REJECT, onReject);
    socket.on(SOCKET_EVENTS.CALL_END, onEnd);
    socket.on(SOCKET_EVENTS.CALL_BUSY, onBusy);

    return () => {
      socket.off(SOCKET_EVENTS.CALL_RINGING, onRinging);
      socket.off(SOCKET_EVENTS.CALL_OFFER, onOffer);
      socket.off(SOCKET_EVENTS.CALL_ANSWER, onAnswer);
      socket.off(SOCKET_EVENTS.CALL_ICE_CANDIDATE, onIceCandidate);
      socket.off(SOCKET_EVENTS.CALL_ACCEPT, onAccept);
      socket.off(SOCKET_EVENTS.CALL_REJECT, onReject);
      socket.off(SOCKET_EVENTS.CALL_END, onEnd);
      socket.off(SOCKET_EVENTS.CALL_BUSY, onBusy);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [socket]);

  const placeCall = useCallback(
    async ({ calleeId, calleeName, calleeImage, type, conversationId }) => {
      setCallError(null);
      const localCallId = `pending-${Date.now()}`;
      setActiveCall({
        callId: localCallId,
        type,
        direction: 'outgoing',
        status: 'ringing',
        peer: { id: calleeId, name: calleeName, profileImage: calleeImage },
      });

      socket.emit(SOCKET_EVENTS.CALL_INVITE, { calleeId, type, conversationId }, async (ack) => {
        if (ack?.callId) {
          setActiveCall((prev) => (prev ? { ...prev, callId: ack.callId } : prev));
          await webrtc.startCall({ calleeId, callId: ack.callId, type });
        }
      });
    },
    [socket, webrtc]
  );

  const acceptCall = useCallback(async () => {
    if (!incomingCall) return;
    const { callId, type, caller } = incomingCall;
    setActiveCall({
      callId,
      type,
      direction: 'incoming',
      status: 'connecting',
      peer: { id: caller.id, name: caller.name, profileImage: caller.profileImage },
    });
    setIncomingCall(null);
    await webrtc.prepareToAnswer({ callerId: caller.id, callId, type });
    socket.emit(SOCKET_EVENTS.CALL_ACCEPT, { callId, callerId: caller.id });
  }, [incomingCall, socket, webrtc]);

  const declineCall = useCallback(() => {
    if (!incomingCall) return;
    socket.emit(SOCKET_EVENTS.CALL_REJECT, { callId: incomingCall.callId, callerId: incomingCall.caller.id });
    setIncomingCall(null);
  }, [incomingCall, socket]);

  const hangUp = useCallback(() => {
    webrtc.endCall();
    setActiveCall(null);
  }, [webrtc]);

  return (
    <CallContext.Provider
      value={{
        incomingCall,
        activeCall,
        callError,
        setCallError,
        webrtc,
        placeCall,
        acceptCall,
        declineCall,
        hangUp,
      }}
    >
      {children}
    </CallContext.Provider>
  );
}

export function useCall() {
  const ctx = useContext(CallContext);
  if (!ctx) throw new Error('useCall must be used within CallProvider');
  return ctx;
}

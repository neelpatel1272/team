import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { getSocket, connectSocket } from '../services/socket';
import { SOCKET_EVENTS } from '../utils/socketEvents';
import { NOTIFICATION_API } from '../services/api';

const SocketContext = createContext(null);

export function SocketProvider({ children }) {
  const { token, user } = useAuth();
  const [connectionState, setConnectionState] = useState('connecting'); // connecting | connected | reconnecting | offline
  const [onlineUserIds, setOnlineUserIds] = useState(new Set());
  const [notifications, setNotifications] = useState([]);
  const [unreadNotifCount, setUnreadNotifCount] = useState(0);

  useEffect(() => {
    if (!token || !user) return undefined;
    const socket = connectSocket(token);

    const onConnect = () => setConnectionState('connected');
    const onDisconnect = () => setConnectionState('reconnecting');
    const onConnectError = () => setConnectionState('offline');
    const onPresenceSync = ({ onlineUserIds: ids }) => setOnlineUserIds(new Set(ids));
    const onUserOnline = ({ userId }) => setOnlineUserIds((prev) => new Set(prev).add(userId));
    const onUserOffline = ({ userId }) =>
      setOnlineUserIds((prev) => {
        const next = new Set(prev);
        next.delete(userId);
        return next;
      });
    const onNotification = ({ notification }) => {
      setNotifications((prev) => [notification, ...prev]);
      setUnreadNotifCount((c) => c + 1);
    };

    socket.on(SOCKET_EVENTS.CONNECT, onConnect);
    socket.on(SOCKET_EVENTS.DISCONNECT, onDisconnect);
    socket.on(SOCKET_EVENTS.CONNECT_ERROR, onConnectError);
    socket.on(SOCKET_EVENTS.PRESENCE_SYNC, onPresenceSync);
    socket.on(SOCKET_EVENTS.USER_ONLINE, onUserOnline);
    socket.on(SOCKET_EVENTS.USER_OFFLINE, onUserOffline);
    socket.on(SOCKET_EVENTS.NOTIFICATION_NEW, onNotification);

    if (socket.connected) setConnectionState('connected');

    NOTIFICATION_API.list()
      .then(({ data }) => {
        setNotifications(data.data.notifications);
        setUnreadNotifCount(data.data.unreadCount);
      })
      .catch(() => {});

    return () => {
      socket.off(SOCKET_EVENTS.CONNECT, onConnect);
      socket.off(SOCKET_EVENTS.DISCONNECT, onDisconnect);
      socket.off(SOCKET_EVENTS.CONNECT_ERROR, onConnectError);
      socket.off(SOCKET_EVENTS.PRESENCE_SYNC, onPresenceSync);
      socket.off(SOCKET_EVENTS.USER_ONLINE, onUserOnline);
      socket.off(SOCKET_EVENTS.USER_OFFLINE, onUserOffline);
      socket.off(SOCKET_EVENTS.NOTIFICATION_NEW, onNotification);
    };
  }, [token, user]);

  const markAllNotificationsRead = useCallback(async () => {
    await NOTIFICATION_API.markAllRead();
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    setUnreadNotifCount(0);
  }, []);

  const isOnline = useCallback((userId) => onlineUserIds.has(String(userId)), [onlineUserIds]);

  return (
    <SocketContext.Provider
      value={{
        socket: getSocket(),
        connectionState,
        onlineUserIds,
        isOnline,
        notifications,
        unreadNotifCount,
        markAllNotificationsRead,
      }}
    >
      {children}
    </SocketContext.Provider>
  );
}

export function useSocketContext() {
  const ctx = useContext(SocketContext);
  if (!ctx) throw new Error('useSocketContext must be used within SocketProvider');
  return ctx;
}
